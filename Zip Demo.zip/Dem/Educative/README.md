# Educative
Django Education Website (This is a Demo project I have been assigned to)

## Project idea

**Activities**
- Template from bootstarpmade.com with customization
- Use class based views
- List all courses
- View detail of a course
- User registration
- User login
- Enroll course

**Copyright**

I used some photos from unsplash and some videos from youtube. This is for learning purpose only. I don't hold any rights of these assets.

### Deployment
The project is deployed on [Heroku](https://educative-py.herokuapp.com/).
